package com.company;

public class Main {

    public static void main(String[] args) {
	int i =5;
	int j =10;
	int k = i+j;
        System.out.println(k);
    }
}
