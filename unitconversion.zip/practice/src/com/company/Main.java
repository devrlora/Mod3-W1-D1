package com.company;

public class Main {

    public static void main(String[] args) {
        double inches = 1000d;
        double convertedMeters = inches *  0.0254d;
        System.out.println(inches + " inches = " + convertedMeters + " meters");
    }
}
