package com.company;

public class unitconversion {
    public static void main(String[] args) {
        double inches = 10d;
        double convertedMeters = inches *  0.0254d;
        System.out.println("Converted inches = " + convertedMeters);
    }
}

